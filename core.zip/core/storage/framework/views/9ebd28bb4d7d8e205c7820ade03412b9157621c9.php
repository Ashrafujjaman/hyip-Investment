<?php $__env->startSection('content'); ?>
<?php
    $registerContent = getContent('register.content',true);
?>
    <!-- account section start -->
    <div class="account-section bg_img" data-background="<?php echo e(getImage('assets/images/frontend/register/'.@$registerContent->data_values->section_bg)); ?>">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-xl-5 col-lg-7">
            <div class="account-card">
              <div class="account-card__header bg_img overlay--one" data-background="<?php echo e(getImage('assets/images/frontend/register/'.@$registerContent->data_values->card_bg)); ?>">
                <h2 class="section-title"><?php echo e(__(@$registerContent->data_values->heading_w)); ?> <span class="base--color"><?php echo e(__(@$registerContent->data_values->heading_c)); ?></span></h2>
                <p><?php echo e(__(@$registerContent->data_values->sub_heading)); ?></p>
              </div>
              <div class="account-card__body">
                <form action="<?php echo e(route('user.register')); ?>" class="mt-4" onsubmit="return submitUserForm();" method="post">
                  <?php echo csrf_field(); ?>
                    <?php if(session()->get('reference') != null): ?>
                    <div class="form-group">
                        <label><?php echo app('translator')->get('Reference'); ?></label>
                        <input type="text" name="referBy" class="form-control" id="referenceBy"
                        placeholder="<?php echo e(trans('Reference By')); ?>"
                        value="<?php echo e(session()->get('reference')); ?>" readonly>
                    </div>
                    <?php endif; ?>
                  <div class="form-group">
                    <label><?php echo app('translator')->get('First Name'); ?></label>
                    <input type="text" class="form-control" name="firstname" value="<?php echo e(old('firstname')); ?>" placeholder="<?php echo app('translator')->get('First Name'); ?>" required>
                  </div>
                  <div class="form-group">
                    <label><?php echo app('translator')->get('Last Name'); ?></label>
                    <input type="text" class="form-control" name="lastname" value="<?php echo e(old('lastname')); ?>" placeholder="<?php echo app('translator')->get('Last Name'); ?>" required>
                  </div>
                  <div class="form-group">
                    <label><?php echo e(__('Country')); ?></label>
                    <select name="country" id="country" class="form-control">
                        <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option data-mobile_code="<?php echo e($country->dial_code); ?>" value="<?php echo e($country->country); ?>" data-code="<?php echo e($key); ?>"><?php echo e(__($country->country)); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </div>
                  <div class="form-group">
                    <label><?php echo e(trans('Mobile')); ?></label>
                    <div class="input-group ">
                        <div class="input-group-prepend">
                            <span class="input-group-text mobile-code">
                                                    
                            </span>
                            <input type="hidden" name="mobile_code">
                        </div>
                        <input type="text" name="mobile" class="form-control" value="<?php echo e(old('mobile')); ?>" placeholder="<?php echo app('translator')->get('Your Phone Number'); ?>" required>
                    </div>
                  </div>
                  <div class="form-group">
                    <label><?php echo app('translator')->get('Email Address'); ?></label>
                    <input type="email" name="email" class="form-control" value="<?php echo e(old('email')); ?>" placeholder="<?php echo app('translator')->get('Enter email address'); ?>" required>
                  </div>
                  <div class="form-group">
                    <label><?php echo app('translator')->get('User Name'); ?></label>
                    <input type="text" name="username" class="form-control" value="<?php echo e(old('username')); ?>" placeholder="<?php echo app('translator')->get('User Name'); ?>" required>
                  </div>
                  <div class="form-group">
                    <label><?php echo app('translator')->get('Password'); ?></label>
                    <input type="password" name="password" class="form-control" placeholder="<?php echo app('translator')->get('Enter password'); ?>" required>
                  </div>
                  <div class="form-group">
                    <label><?php echo e(trans('Confirm Password')); ?></label>
                    <input type="password" name="password_confirmation" class="form-control" placeholder="<?php echo app('translator')->get('Confirm Password'); ?>" required>
                  </div>
                  <div class="form-group d-flex justify-content-center">
                    <?php echo recaptcha() ?>
                  </div>
                  <?php echo $__env->make($activeTemplate.'partials.custom-captcha', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                  <?php
                      $links = getContent('links.element','','',1);
                  ?>
                  <div class="form-row mt-2">
                    <div class="col-md-12">
                      <input type="checkbox" name="terms" required> <span class="f-size-14 ml-2"><?php echo app('translator')->get('I agree with'); ?> <?php $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                    <a class="base--color" href="<?php echo e(route('linkDetails',[slug($link->data_values->title),$link->id])); ?>"> <?php echo app('translator')->get($link->data_values->title); ?></a>
                    <?php if(!$loop->last): ?> , <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></span>
                    </div>
                  </div>
                  <div class="mt-3">
                    <button type="submit" class="cmn-btn"><?php echo app('translator')->get('SignUp Now'); ?></button>
                  </div>
                  <div class="form-row mt-2">
                    <div class="col-sm-6">
                      <p class="f-size-14"><?php echo app('translator')->get('Have an account?'); ?> <a href="<?php echo e(route('user.login')); ?>" class="base--color"><?php echo app('translator')->get('Login'); ?></a></p>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- account section end -->
<?php $__env->stopSection(); ?>
<?php $__env->startPush('style'); ?>
<style>
  .input-group-text{
    color: #fff;
  }
</style>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('script'); ?>
    <script>
      "use strict";
          <?php if($mobile_code): ?>
          $(`option[data-code=<?php echo e($mobile_code); ?>]`).attr('selected','');
          <?php endif; ?>

          $('select[name=country]').change(function(){
              $('input[name=mobile_code]').val($('select[name=country] :selected').data('mobile_code'));
              $('.mobile-code').text('+'+$('select[name=country] :selected').data('mobile_code'));
          });
          $('input[name=mobile_code]').val($('select[name=country] :selected').data('mobile_code'));
          $('.mobile-code').text('+'+$('select[name=country] :selected').data('mobile_code'));
        function submitUserForm() {
            var response = grecaptcha.getResponse();
            if (response.length == 0) {
                document.getElementById('g-recaptcha-error').innerHTML = '<span style="color:red;"><?php echo app('translator')->get("Captcha field is required."); ?></span>';
                return false;
            }
            return true;
        }

        function verifyCaptcha() {
            document.getElementById('g-recaptcha-error').innerHTML = '';
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make($activeTemplate.'layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hipe\core\resources\views/templates/bit_gold/user/auth/register.blade.php ENDPATH**/ ?>
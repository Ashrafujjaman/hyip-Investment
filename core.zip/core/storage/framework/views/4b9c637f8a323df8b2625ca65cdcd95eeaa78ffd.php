<?php echo  tawkto() ?>
<?php echo  analytics() ?><?php /**PATH C:\xampp\htdocs\hipe\core\resources\views/partials/plugins.blade.php ENDPATH**/ ?>
<?php $__env->startSection('panel'); ?>


    <div class="row">

        <div class="col-lg-12">
            <div class="card b-radius--10 ">
                <div class="card-body p-0">
                    <div class="table-responsive--md  table-responsive">
                        <table class="table table--light style--two">
                            <thead>
                            <tr>
                                <th scope="col"><?php echo app('translator')->get('Name'); ?></th>
                                <th scope="col"><?php echo app('translator')->get('Time'); ?></th>
                                <th scope="col"><?php echo app('translator')->get('Action'); ?></th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $team; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td data-label="<?php echo app('translator')->get('Name'); ?>"><?php echo e($data->name); ?></td>
                                <td data-label="<?php echo app('translator')->get('Time'); ?>"><?php echo e($data->time); ?> <?php echo app('translator')->get('Hours'); ?></td>
                                <td data-label="<?php echo app('translator')->get('Action'); ?>">
                                     <a href="javascript:void(0)"
                                   data-id="<?php echo e($data->id); ?>"
                                   data-name="<?php echo e($data->name); ?>"
                                   data-time="<?php echo e($data->time); ?>"
                                   data-route="<?php echo e(route('admin.time-update', $data->id)); ?>"
                                   data-toggle="modal" data-target="#editModal"
                                   class="icon-btn "><i class="las la-pen"></i></a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td class="text-muted text-center" colspan="100%"><?php echo app('translator')->get('Data Not Found'); ?></td>
                                </tr>
                            <?php endif; ?>

                            </tbody>
                        </table><!-- table end -->
                    </div>
                </div>
            </div><!-- card end -->
        </div>


    </div>


    <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="myModalLabel"> <?php echo app('translator')->get('Add New Time'); ?></h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                                aria-hidden="true">×</span></button>
                </div>
                <form id="frmProducts" method="post" action="<?php echo e(route('admin.time-store')); ?>" class="form-horizontal"
                      enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">

                        <div class="form-group">
                            <label><?php echo app('translator')->get('Time Name:'); ?> </label>
                            <input type="text" class="form-control" name="name" required>
                        </div>

                        <div class="form-group">
                            <label><?php echo app('translator')->get('Time in Hours'); ?></label>
                            <div class="input-group">
                                <input type="number" class="form-control" name="time" required>
                                <div class="input-group-prepend">
                                    <div class="input-group-text"><?php echo app('translator')->get('Hours'); ?></div>
                                </div>
                            </div>
                        </div>

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn--dark" data-dismiss="modal"> <?php echo app('translator')->get('Close'); ?></button>
                        <button type="submit" class="btn btn--primary"><i class="fa fa-send"></i> <?php echo app('translator')->get('Save'); ?></button>
                    </div>
                </form>
            </div>
        </div>

    </div>

    <div class="modal fade" id="editModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
         aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="myModalLabel"> <?php echo app('translator')->get('Edit Time'); ?></h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                                aria-hidden="true">×</span></button>
                </div>
                <form id="frmProducts" class="edit-route form-horizontal" method="post" action=""
                      enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('put'); ?>
                    <div class="modal-body">

                        <div class="form-group">
                            <label><?php echo app('translator')->get('Time Name:'); ?> </label>
                            <input type="text" class="form-control" value="" name="name" required>
                        </div>

                        <div class="form-group">
                            <label><?php echo app('translator')->get('Time in Hours'); ?></label>
                            <div class="input-group">
                                <input type="number" class="form-control" name="time" value="" required>
                                <div class="input-group-prepend">
                                    <div class="input-group-text"><?php echo app('translator')->get('Hours'); ?></div>
                                </div>
                            </div>
                        </div>

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn--dark" data-dismiss="modal"><?php echo app('translator')->get('Close'); ?></button>
                        <button type="submit" class="btn btn--primary"><i class="fa fa-send"></i> <?php echo app('translator')->get('Update'); ?>
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php $__env->startPush('breadcrumb-plugins'); ?>
    <button type="button" data-target="#myModal" data-toggle="modal"
            class="btn btn-sm btn--primary box--shadow1 text--small"><i class="fa fa-fw fa-plus"></i><?php echo app('translator')->get('Add New'); ?>
    </button>
<?php $__env->stopPush(); ?>


<?php $__env->startPush('script'); ?>
    <script>
        $(function ($) {
            "use strict";

            $('.editBtn').on('click', function () {
                var modal = $('#editModal');
                modal.find('.edit-route').attr('action', $(this).data('route'));
                modal.find('input[name=name]').val($(this).data('name'));
                modal.find('input[name=time]').val($(this).data('time'));
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hipe\core\resources\views/admin/time_setting/index.blade.php ENDPATH**/ ?>